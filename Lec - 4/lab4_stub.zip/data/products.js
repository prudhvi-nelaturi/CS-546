// TODO: Export and implement the following functions in ES6 format
const create = async (
  productName,
  productDescription,
  modelNumber,
  price,
  manufacturer,
  manufacturerWebsite,
  keywords,
  categories,
  dateReleased,
  discontinued
) => {};

const getAll = async () => {};

const get = async (id) => {};

const remove = async (id) => {};

const rename = async (id, newProductName) => {};
