// This file is where you will import your functions from the two other files and run test cases on your functions by calling them with various inputs.  We will not use this file for grading and is only for your testing purposes to make sure:

// 1. Your functions in your 2 files are exporting correctly.

// 2. They are returning the correct output based on the input supplied (throwing errors when you're supposed to, returning the right results etc..).

// Note:
// 1. You will need that calls your functions like the example below.
// 2. Do not create any other files beside the 'package.json' - meaning your zip should only have the files and folder in this stub and a 'package.json' file.
// 3. Submit all files (including package.json) in a zip with your name in the following format: LastName_FirstName.zip.
// 4. DO NOT submit a zip containing your node_modules folder.

import * as authors from './authors.js';
import * as books from './books.js';
import axios from 'axios';

// try {
//   let id = '1871e6d7-551f-41cb-9a07-08240b86c95c';
//   let result = await authors.getAuthorById(id);
//   console.log(result); //returns the object that was found
// } catch (e) {
//   console.log(e.message);
// }

// try {
//   let id = '11';
//   let result = await authors.getAuthorById(null);
//   console.log(result); //returns the object that was found
// } catch (e) {
//   console.log(e.message);
// }

// try {
//   let id = '7989fa5e-5617-43f7-a931-46036f9dbcff';
//   let result = await authors.getAuthorById(id);
//   console.log(result); //Author not found Error
// } catch (e) {
//   console.log(e.message);
// }

// try {
//   let result = await authors.searchAuthorsByAge(40);
//   console.log(result);
//   // Returns:
//   //["Mayer Staddart", "Madelaine Armatage", "Adorne Byrant"...] //Only the first three are shown
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await authors.searchAuthorsByAge(null); // Throws Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message); //Throws Error
// }

try {
  let result = await authors.getBooksByState('nj');
  console.log(result);
} catch (error) {
  console.log(error.message);
}

// try {
//   let result = await authors.getBooksByState(); // Throws Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message); //throws Error
// }

// try {
//   let result = await authors.searchAuthorsByHometown('New York City', 'NY');
//   console.log(result);
//   //Returns
//   //["Maurice McKinless","Mayer Stadart"] // there are others, but this an example of just a few authors
// } catch (error) {
//   console.log(error.message); //throws Error
// }

// try {
//   let result = await authors.searchAuthorsByHometown(); // Throws Error
//   console.log(result);
//   //Returns
//   //["Maurice McKinless","Mayer Stadart"] // there are others, but this an example of just a few authors
// } catch (error) {
//   console.log(error.message); //throws Error
// }

// try {
//   let result = await authors.getAuthorBooks(
//     '69b3f32f-5690-49d1-b9a6-9d2dd7d6e6cd'
//   ); //
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await authors.getAuthorBooks(); // Throws Error:
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.getBookById('eb32b579-f7d8-4b92-b95b-92138677e2b6');
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.getBookById('7989fa5e-5617-43f7-a931-46036f9dbcff'); // Throws book not found Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.booksByPageCount(300, 500);
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.booksByPageCount(); // Throws Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.sameYear(2012);
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.sameYear('foo bar'); // Throws Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.minMaxPrice();
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.searchBooksByPublisher('Zoozzy');
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }

// try {
//   let result = await books.searchBooksByPublisher(); // Throws Error
//   console.log(result);
// } catch (error) {
//   console.log(error.message);
// }
