//TODO EXPORT AND IMPLEMENT THE FOLLOWING FUNCTIONS IN ES6 FORMAT
//Authors data link: https://gist.githubusercontent.com/graffixnyc/a086a55e04f25e538b5d52a095fe4467/raw/e9f835e9a5439a647a24fa272fcb8f5a2b94dece/authors.json

//you must use axios to get the data
import axios from 'axios';
import { getAuthors, getBooks } from './helpers.js';

export const getAuthorById = async (id) => {
  let condition =
    /^[a-zA-Z0-9]{8}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{4}-[a-zA-Z0-9]{12}$/;

  if (id === undefined || typeof id !== 'string') {
    throw new Error('please provide the id in a string format');
  }
  if (!condition.test(id)) {
    throw new Error('Please provide the valid id');
  }
  if (id.trim() == '') {
    throw new Error('id is empty');
  }
  let obtainedData = await getAuthors();
  // console.log(obtainedData);
  let result = obtainedData.find((obj) => obj.id === id);
  if (condition.test(id) && result === undefined && !result) {
    throw new Error('Author not found');
  } else {
    return result;
  }
};

export const searchAuthorsByAge = async (age) => {
  // console.log(age);

  if (age === undefined || age === null) {
    throw new Error('Please provide the age');
  }
  if (typeof age !== 'number') {
    throw new Error('Please provide valid number');
  }
  if (age < 1 || age > 100) {
    throw new Error('Age must be between 1 and 100.');
  }
  if (!Number.isInteger(age)) {
    throw new Error('Age must be a whole number.');
  }
  const stringValue = age.toString();
  // console.log(stringValue);
  if (stringValue.includes('.')) {
    throw new Error('Please provide valid whole number without a period');
  }

  let today = new Date();
  // let dob = new Date(age);
  function checkAge(obj) {
    let birthDate = new Date(obj.date_of_birth);
    let Authorage = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();

    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      Authorage--;
    }
    if (Authorage >= age) {
      // console.log(`${obj.first_name} ${obj.last_name}`);
      return obj.first_name;
    }
    // return;
  }
  let result = [];
  let obtainedData = await getAuthors();
  let resultantObjects = obtainedData.filter(checkAge);
  resultantObjects.forEach((element) => {
    result.push(`${element.first_name} ${element.last_name}`);
  });
  return result;
};

export const getBooksByState = async (state) => {
  if (state === undefined || state === null) {
    throw new Error('Please provide the valid state');
  }
  if (typeof state !== 'string') {
    throw new Error('The provided state must be a proper string');
  }

  // Trim the state parameter to remove any leading or trailing whitespace
  state = state.trim().toUpperCase();
  const validStates = [
    'AL',
    'AK',
    'AZ',
    'AR',
    'CA',
    'CO',
    'CT',
    'DE',
    'FL',
    'GA',
    'HI',
    'ID',
    'IL',
    'IN',
    'IA',
    'KS',
    'KY',
    'LA',
    'ME',
    'MD',
    'MA',
    'MI',
    'MN',
    'MS',
    'MO',
    'MT',
    'NE',
    'NV',
    'NH',
    'NJ',
    'NM',
    'NY',
    'NC',
    'ND',
    'OH',
    'OK',
    'OR',
    'PA',
    'RI',
    'SC',
    'SD',
    'TN',
    'TX',
    'UT',
    'VT',
    'VA',
    'WA',
    'WV',
    'WI',
    'WY',
  ];
  if (state.length !== 2) {
    throw new Error('Please provide state that has only two characters');
  }

  // Check if the state parameter is a valid state abbreviation
  if (!validStates.includes(state)) {
    throw new Error('Please provide a valid state that exists');
  }
  function checkState(obj) {
    if (obj.HometownState === state) {
      return obj;
    }
  }
  let bookIDs = [];
  // let result = [];
  let obtainedAuthor = await getAuthors();
  let filteredAuthor = obtainedAuthor.filter(checkState);
  filteredAuthor.forEach((element) => {
    bookIDs.push(element.books);
  });
  let obtainedBook = await getBooks();

  // bookIDs.forEach((element) => {
  let titlesArray = bookIDs.map((idArray) =>
    idArray.map((id) => {
      let book = obtainedBook.find((book) => book.id === id);
      return book ? book.title : 'Title not found';
    })
  );

  let flatArray = titlesArray.flat();
  // console.log(titlesArray);
  return flatArray;
  // });
  // console.log(bookIDs);

  // let obtainedData = await getBooks();
  // console.log(obtainedData);
};

export const searchAuthorsByHometown = async (town, state) => {
  if (
    town === null ||
    town === undefined ||
    state === null ||
    state === undefined
  ) {
    throw new Error('Please provide town or state');
  }
  if (typeof town !== 'string' || typeof state !== 'string') {
    throw new Error('Please provide town and state as strings');
  }
  state = state.trim().toUpperCase();
  town = town.trim().toUpperCase();
  const validStates = [
    'AL',
    'AK',
    'AZ',
    'AR',
    'CA',
    'CO',
    'CT',
    'DE',
    'FL',
    'GA',
    'HI',
    'ID',
    'IL',
    'IN',
    'IA',
    'KS',
    'KY',
    'LA',
    'ME',
    'MD',
    'MA',
    'MI',
    'MN',
    'MS',
    'MO',
    'MT',
    'NE',
    'NV',
    'NH',
    'NJ',
    'NM',
    'NY',
    'NC',
    'ND',
    'OH',
    'OK',
    'OR',
    'PA',
    'RI',
    'SC',
    'SD',
    'TN',
    'TX',
    'UT',
    'VT',
    'VA',
    'WA',
    'WV',
    'WI',
    'WY',
  ];
  if (state.length !== 2) {
    throw new Error('Please provide state that has only two characters');
  }

  // Check if the state parameter is a valid state abbreviation
  if (!validStates.includes(state)) {
    throw new Error('state parameter is not a valid state parameter');
  }
  function checkTownAndState(obj) {
    // console.log(obj.HometownCity);
    // console.log(town);
    if (
      obj.HometownCity.toUpperCase() === town.toUpperCase() &&
      obj.HometownState.toUpperCase() === state.toUpperCase()
    ) {
      return obj.first_name;
    }
  }
  let AuthorNames = [];
  let obtaineddata = await getAuthors();
  let filteredAuthor = obtaineddata.filter(checkTownAndState);
  // console.log(filteredAuthor);
  filteredAuthor.forEach((element) => {
    AuthorNames.push(`${element.first_name} ${element.last_name}`);
  });
  AuthorNames.sort();
  return AuthorNames;
  // console.log(AuthorNames);
};

export const getAuthorBooks = async (authorid) => {
  function getBookIDs(obj) {
    if (obj.id === authorid) {
      return obj.books;
    }
  }
  if (authorid === null || authorid === undefined) {
    throw new Error('Please provide the authorid');
  }
  if (typeof authorid !== 'string') {
    throw new Error('Please provide valid author ID as string format');
  }
  authorid = authorid.trim();
  if (authorid === null || authorid === undefined) {
    throw new Error('Please provide the authorid');
  }

  if (authorid === '') {
    throw new Error('Authorid should not be empty');
  }
  let bookIDs = [];
  let obtainedData = await getAuthors();
  let filteredAuthor = obtainedData.filter(getBookIDs);
  let obtainedBookData = await getBooks();
  filteredAuthor.forEach((element) => {
    bookIDs.push(element.books);
  });
  let titlesArray = bookIDs.map((idArray) =>
    idArray.map((id) => {
      let book = obtainedBookData.find((book) => book.id === id);
      return book ? book.title : 'Title not found';
    })
  );
  return titlesArray.flat();
};
