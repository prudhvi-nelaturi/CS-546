//TODO EXPORT AND IMPLEMENT THE FOLLOWING FUNCTIONS IN ES6 FORMAT
//Books data link: https://gist.githubusercontent.com/graffixnyc/3381b3ba73c249bfcab1e44d836acb48/raw/e14678cd750a4c4a93614a33a840607dd83fdacc/books.json
import { getAuthors, getBooks } from './helpers.js';

export const getBookById = async (id) => {
  if (id === null || id === undefined) {
    throw new Error('Please provide id');
  }
  //   console.log(typeof id);
  if (typeof id !== 'string') {
    throw new Error('Please provide valid string as id');
  }
  id = id.trim();
  if (id === '') {
    throw new Error('id should not be empty');
  }
  let obtainedData = await getBooks();
  let result = obtainedData.find((obj) => obj.id === id);
  if (!result) {
    throw new Error('Book not found');
  }
  return result;
};

export const booksByPageCount = async (min, max) => {
  function countMatchData(obj) {
    if (obj.pageCount >= min && obj.pageCount <= max) {
      result.push(obj.id);
    }
  }
  if (min === null || max === null || min === undefined || max === undefined) {
    throw new Error(
      'Please provide all the paramters. Both max and min should be provided'
    );
  }
  if (typeof min !== 'number' || typeof max !== 'number') {
    throw new Error('min and max should be a number');
  }
  if (!Number.isInteger(min)) {
    throw new Error('Min must be a whole number.');
  }
  if (!Number.isInteger(max)) {
    throw new Error('Max must be a whole number.');
  }
  if (min > max) {
    throw new Error('max should be greater than min');
  }
  if (min < 0 || max < 0) {
    throw new Error(
      'Please provide posivitve whole number for both min and max'
    );
  }
  let result = [];
  let obtainedData = await getBooks();
  let filteredBookData = obtainedData.filter(countMatchData);
  // console.log(filteredBookData);
  return result;
};

export const sameYear = async (year) => {
  if (year === null || year === undefined) {
    throw new Error('Please provide the year');
  }
  if (typeof year !== 'number') {
    throw new Error('Year must be a number');
  }
  if (!Number.isInteger(year)) {
    throw new Error('year must be a whole number.');
  }
  if (year < 1900 || year > 2024) {
    throw new Error(
      'year must be a valid positive number and should be between 1900 and 2024'
    );
  }
  let result = [];
  function checkYear(obj) {
    let publication_Date = new Date(obj.publicationDate).getFullYear();
    // result.push(publication_Date);
    if (publication_Date === year) {
      result.push(obj);
    }
  }
  let obtainedData = await getBooks();
  let filteredBookData = obtainedData.filter(checkYear);
  return result;
};

export const minMaxPrice = async () => {
  let cheapest = [];
  let cheapestPrice = [];
  let mostExpensive = [];
  let mostExpensivePrice = [];
  function minMax(obj) {
    if (mostExpensivePrice.length === 0) {
      mostExpensivePrice.push(obj.price);
      mostExpensive.push(obj.id);
    } else if (mostExpensivePrice[0] < obj.price) {
      mostExpensivePrice = [];
      mostExpensive = [];
      mostExpensivePrice.push(obj.price);
      mostExpensive.push(obj.id);
    } else if (mostExpensivePrice[0] === obj.price) {
      mostExpensivePrice.push(obj.price);
      mostExpensive.push(obj.id);
    }
    if (cheapestPrice.length === 0) {
      cheapestPrice.push(obj.price);
      cheapest.push(obj.id);
    } else if (cheapestPrice[0] > obj.price) {
      cheapest = [];
      cheapestPrice = [];
      cheapest.push(obj.id);
      cheapestPrice.push(obj.price);
    } else if (cheapestPrice[0] === obj.price) {
      cheapest.push(obj.id);
      cheapestPrice.push(obj.price);
    }
  }
  let obtainedData = await getBooks();
  let filteredData = obtainedData.filter(minMax);
  let result = { cheapest: cheapest, mostExpensive: mostExpensive };
  // console.log(mostExpensivePrice);
  return result;
  // console.log(cheapestPrice);
};

export const searchBooksByPublisher = async (publisher) => {
  if (publisher === null || publisher === undefined) {
    throw new Error('Please provide the publisher parameter');
  }
  if (typeof publisher !== 'string') {
    throw new Error('Please provide publisher parameter as string');
  }
  publisher = publisher.trim();
  if (publisher === '' || publisher === ' ') {
    throw new Error('Please provide valid publisher but not spaces');
  }
  function searchPublisher(obj) {
    if (obj.publisher === publisher) {
      result.push(obj.id);
    }
  }
  let result = [];
  let obtainedData = await getBooks();
  let filteredBookData = obtainedData.filter(searchPublisher);
  if (result.length === 0) {
    throw new Error('Please provide the valid publisher that has published');
  } else {
    return result;
  }
};
