import {data} from './getdata.js';

console.log(data ? data.length : 'no data');
console.log('After main is run');
