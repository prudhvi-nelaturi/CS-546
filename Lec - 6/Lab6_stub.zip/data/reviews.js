// This data file should export all functions using the ES6 standard as shown in the lecture code

const createReview = async (
  productId,
  title,
  reviewerName,
  review,
  rating
) => {};

const getAllReviews = async (productId) => {};

const getReview = async (reviewId) => {};

const updateReview = async (reviewId, updateObject) => {};

const removeReview = async (reviewId) => {};
