export const mongoConfig = {
  serverUrl: 'mongodb://localhost:27017/',
  database: 'apiBasedBlog'
};
