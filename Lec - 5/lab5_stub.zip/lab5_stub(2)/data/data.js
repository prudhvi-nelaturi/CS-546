/*Here, you can export the data functions
to get the comapnies, people, getCompanyByID, getPersonById.  You will import these functions into your routing files and call the relevant function depending on the route. 
*/

const getCompanies = async () => {};

const getPeople = async () => {};

const getCompanyById = async (id) => {};

const getPersonById = async (id) => {};
