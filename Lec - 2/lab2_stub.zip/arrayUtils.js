/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let arrayPartition = (arrayToPartition, partitionFunc) => {
  //code goes here
};

let arrayShift = (arr, n) => {
  //code goes here
};

let matrixOne = (matrix) => {
  //code goes here
};
