/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let objectStats = (arrObjects) => {
  //Code goes here
};

let nestedObjectsDiff = (obj1, obj2) => {
  //Code goes here
};

let mergeAndSumValues = (...args) => {
  //this function takes in a variable number of objects that's what the ...args signifies
};
