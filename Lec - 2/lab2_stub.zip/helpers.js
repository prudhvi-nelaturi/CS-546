/* Todo: Implment any helper functions below 
    and then export them for use in your other files.
*/