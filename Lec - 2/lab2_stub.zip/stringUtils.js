/* Todo: Implment the functions below and then export them
      using the ES6 exports syntax. 
      DO NOT CHANGE THE FUNCTION NAMES
*/

let swapChars = (string1, string2) => {
  //code goes here
};

let longestCommonSubstring = (str1, str2) => {
  //code goes here
};

let palindromeOrIsogram = (arrStrings) => {
  //code goes here
};
